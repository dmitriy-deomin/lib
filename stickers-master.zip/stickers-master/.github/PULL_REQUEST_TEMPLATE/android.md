---
name: Android PR
about: Android Pull Request
---
**Change description**  
[FILL IN WITH DETAILED DESCRIPTION OF THE PROBLEM AND WHAT/HOW IT WAS SOLVE]

**Prerequisites**
- [ ] I have completed the CLA

Note: In order for us to accept pull requests, please complete the Contributor License Agreement by following instructions in [`CONTRIBUTING`](https://github.com/WhatsApp/stickers/blob/master/CONTRIBUTING.md).

@simonzhexu
